﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 租房管理系统
{
    public partial class 主界面 : Form
    {
        static string usernamestr;
        public 主界面()
        {
            usernamestr = "admin";
            InitializeComponent();
        }

        public 主界面(string user)
        {
            usernamestr = user;
            InitializeComponent();
        }

        DBAccess dbAccess = DBAccess.GetInstance();
        string SqlCommand;

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.Text = "房屋租赁管理系统       当前用户：" + usernamestr;
            if (usernamestr.Equals("admin"))
                toolStripButton3.Visible = false;
            else
                toolStripButton2.Visible = false;

            // 下面初始化账户当前余额
            SqlCommand = "select * from 收费标准表 where 标准方案号='1'";
            SqlDataReader reader = dbAccess.GetReaderofCommand(SqlCommand);
            // 给标准收费赋值
            while (reader.Read())
            {
                DBAccess.Balance= double.Parse(reader[5].ToString());  // 当前余额
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        // 点击房屋信息管理 
        private void button1_Click(object sender, EventArgs e)
        {
            splitContainer1.Panel2.Controls.Clear();// 清除画板图片
            房屋信息管理 roominf = new 房屋信息管理(); // 创建房屋信息管理窗体
            roominf.TopLevel = false;
            roominf.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            roominf.WindowState = FormWindowState.Normal;
            roominf.Dock = DockStyle.Fill;
            roominf.KeyPreview = true;
            roominf.Parent = splitContainer1.Panel2;     // 将房屋信息管理窗体放到Panel2面板中
            roominf.Show(); // 显示房屋信息管理窗体
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        // 用户信息管理按钮
        private void button2_Click(object sender, EventArgs e)
        {
            splitContainer1.Panel2.Controls.Clear();
            用户信息管理 userinf = new 用户信息管理();  //创建窗口
            userinf.TopLevel = false;
            userinf.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            userinf.WindowState = FormWindowState.Normal;
            userinf.Dock = DockStyle.Fill;
            userinf.KeyPreview = true;
            userinf.Parent = splitContainer1.Panel2;   // 将创建的窗口加到Panel2面板中
            userinf.Show(); // 窗口显示
        }


        // 修改当前用户密码
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            修改密码 cupe = new 修改密码(usernamestr); // 将用户名传给修改密码框
            cupe.ShowDialog();
        }

        // 点击管理员信息管理 
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            管理员信息管理 minf = new 管理员信息管理();
            minf.ShowDialog();
        }

        // 租贷信息管理 按钮
        private void button3_Click(object sender, EventArgs e)
        {
            splitContainer1.Panel2.Controls.Clear();
            租贷信息管理 rentinf = new 租贷信息管理();
            rentinf.TopLevel = false;
            rentinf.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            rentinf.WindowState = FormWindowState.Normal;
            rentinf.Dock = DockStyle.Fill;
            rentinf.KeyPreview = true;
            rentinf.Parent = splitContainer1.Panel2;
            rentinf.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            splitContainer1.Panel2.Controls.Clear();
            水电费管理 binf = new 水电费管理();
            binf.TopLevel = false;
            binf.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            binf.WindowState = FormWindowState.Normal;
            binf.Dock = DockStyle.Fill;
            binf.KeyPreview = true;
            binf.Parent = splitContainer1.Panel2;
            binf.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            收费标准 oset = new 收费标准();
            oset.ShowDialog();
        }


        // 点击按钮进入财务收支管理 界面
        private void button5_Click(object sender, EventArgs e)
        {
            splitContainer1.Panel2.Controls.Clear();
            财务收支管理 finance = new 财务收支管理();
            finance.TopLevel = false;
            finance.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            finance.WindowState = FormWindowState.Normal;
            finance.Dock = DockStyle.Fill;
            finance.KeyPreview = true;
            finance.Parent = splitContainer1.Panel2;
            finance.Show();
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
