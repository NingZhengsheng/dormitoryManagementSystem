﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace 租房管理系统
{
    public partial class 财务收支管理 : Form
    {
        public 财务收支管理()
        {
            InitializeComponent();
        }
        DBAccess dbAccess = DBAccess.GetInstance();
        DataSet dataset;
        string SqlCommand;

        private void Finance_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0; // 设置初始选择第0项
            ShowData(); // 将财务收支信息全部显示到界面上
        }
        public bool IsNum(String strNumber)
        {
            Regex objNotNumberPattern = new Regex("[^0-9.-]");
            Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*");
            Regex objTwoMinusPattern = new Regex("[0-9]*[-][0-9]*[-][0-9]*");
            String strValidRealPattern = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$";
            String strValidIntegerPattern = "^([-]|[0-9])[0-9]*$";
            Regex objNumberPattern = new Regex("(" + strValidRealPattern + ")|(" + strValidIntegerPattern + ")");
            return !objNotNumberPattern.IsMatch(strNumber) && !objTwoDotPattern.IsMatch(strNumber) && !objTwoMinusPattern.IsMatch(strNumber) && objNumberPattern.IsMatch(strNumber);
        }


        // 将财务收支信息全部显示到界面上
        private void ShowData()
        {
            SqlCommand = "select * from 财务报表 ";  //查询所有结果
                                                  // 将查询结果放到 是视图表中
            dataset = dbAccess.GetDataset(SqlCommand, "财务报表");
            dataGridView1.DataSource = dataset.Tables[0];
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string bianhao, leixing, jine, date;
                bianhao = textBox1.Text;
                leixing = comboBox1.SelectedItem.ToString();
                jine = textBox2.Text;
                date = dateTimePicker1.Text;
                if (!IsNum(jine))
                    MessageBox.Show("金额不为数字！请修改");
                else
                {
                    SqlCommand = "insert into 财务报表 values('" + bianhao + "','" + leixing + "','" + jine + " 元" + "','" + date + "')";
                    dbAccess.GetSQLCommand(SqlCommand); //添加收支信息到数据库中
                    ShowData(); // 将财务收支信息全部显示到界面上

                    // 更新全局余额数据
                    if (comboBox1.SelectedItem.ToString().Equals("收入"))
                    {
                        DBAccess.Balance = DBAccess.Balance + double.Parse(jine);
                    }
                        
                    else if (comboBox1.SelectedItem.ToString().Equals("支出"))
                    {
                        DBAccess.Balance = DBAccess.Balance - double.Parse(jine);
                    }  
                }
            }
            catch (Exception)
            {
                MessageBox.Show("该数据记录已存在");
            }
        }

    }
}
