﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace 租房管理系统
{
    public partial class 收费标准 : Form
    {
        public 收费标准()
        {
            InitializeComponent();
        }

        DBAccess dbAccess = DBAccess.GetInstance();
        string SqlCommand;

        public bool IsNum(String strNumber)
        {
            Regex objNotNumberPattern = new Regex("[^0-9.-]");
            Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*");
            Regex objTwoMinusPattern = new Regex("[0-9]*[-][0-9]*[-][0-9]*");
            String strValidRealPattern = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$";
            String strValidIntegerPattern = "^([-]|[0-9])[0-9]*$";
            Regex objNumberPattern = new Regex("(" + strValidRealPattern + ")|(" + strValidIntegerPattern + ")");
            return !objNotNumberPattern.IsMatch(strNumber) && !objTwoDotPattern.IsMatch(strNumber) && !objTwoMinusPattern.IsMatch(strNumber) && objNumberPattern.IsMatch(strNumber);
        }

        // 初始化界面
        private void Othersetting_Load(object sender, EventArgs e)
        {
            try
            {
                // 更新当前余额到数据库
                SqlCommand = "update 收费标准表 set 余额='" + DBAccess.Balance + "'where 标准方案号='1'";
                dbAccess.GetSQLCommand(SqlCommand); // 修改收费标准

                string shuiprice, dianprice, wangprice, wuyeprice, yue;
                SqlCommand = "select * from 收费标准表 where 标准方案号='1'";
                SqlDataReader reader = dbAccess.GetReaderofCommand(SqlCommand);
                // 给标准收费赋值
                while (reader.Read())
                {
                    shuiprice = reader[1].ToString();
                    dianprice = reader[2].ToString();
                    wangprice = reader[3].ToString();
                    wuyeprice = reader[4].ToString();
                    textBox1.Text = shuiprice;
                    textBox2.Text = dianprice;
                    textBox3.Text = wangprice;
                    textBox4.Text = wuyeprice;
                    textBox5.Text = DBAccess.Balance + " 元";
                }
                
            }
            catch (Exception)
            {
                MessageBox.Show("收费标准初始化失败");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string shuiprice, dianprice, wangprice, wuyeprice;
                shuiprice = textBox1.Text;
                dianprice = textBox2.Text;
                wangprice = textBox3.Text;
                wuyeprice = textBox4.Text;

                if ((!IsNum(shuiprice)) || (!IsNum(dianprice))|| (!IsNum(wangprice))|| (!IsNum(wuyeprice)))
                {
                    MessageBox.Show("所填单价不是数字，请检查！");
                }
                else
                {
                    MessageBox.Show("确定修改吗？");
                    SqlCommand = "update 收费标准表 set 水价='" + shuiprice + "',电价='" + dianprice 
                        + "',网费='" + wangprice + "',物业费='" + wuyeprice + "'where 标准方案号='1'";
                    dbAccess.GetSQLCommand(SqlCommand); // 修改收费标准
                }
            }
            catch (Exception)
            {
                MessageBox.Show("修改失败！");
            }
        }
    }
}
