﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 租房管理系统
{
    public partial class 水电费管理 : Form
    {
        
        public 水电费管理()
        {
            InitializeComponent();
        }
        static double shuiprice, dianprice;  // 宏定义水电费价格
        DBAccess dbAccess = DBAccess.GetInstance();
        DataSet dataset;
        string SqlCommand;
        double PreBalance;

        private void Billsinf_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            //获取水电费用单价
            try
            {
                SqlCommand = "select * from 收费标准表 where 标准方案号='1'";
                dataset = dbAccess.GetDataset(SqlCommand, "收费标准表");
                shuiprice = double.Parse(dataset.Tables[0].Rows[0][1].ToString()); // 水费价格
                dianprice = double.Parse(dataset.Tables[0].Rows[0][2].ToString()); // 电费价格
            }
            catch (Exception)
            {
                MessageBox.Show("收费标准表数据加载失败！") ;
            }


            //初始化datagridview
            ShowData();  // 将水电费信息全部显示到界面上


            //获取添加选项卡中的combobox数据并将索引置0
            try
            {  // 初始化房号下拉框
                comboBox2.Items.Clear();
                SqlCommand = "select 房屋编号 from 房屋信息表 ";
                dataset = dbAccess.GetDataset(SqlCommand, "房屋信息表");

                DataTable dt = new DataTable();
                dt = dataset.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        comboBox2.Items.Add(dt.Rows[i][0].ToString());
                    }
                }
                comboBox2.SelectedIndex = 0;
            }
            catch (Exception)
            {
                MessageBox.Show("初始化房号下拉框出错！");
            }
        }


        // 添加水电费纪录
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string danhao, roomnum, predianbiao, dianbiao, preshuibiao, shuibiao, jine;
                danhao = textBox2.Text;
                roomnum = comboBox2.SelectedItem.ToString();
                predianbiao = textBox3.Text;
                dianbiao = textBox4.Text;
                preshuibiao = textBox5.Text;
                shuibiao = textBox6.Text;

                // 通过水费价格和水费价格，计算本次金额
                jine = ((double.Parse(dianbiao) - double.Parse(predianbiao)) * dianprice + (double.Parse(shuibiao) - double.Parse(preshuibiao)) * shuiprice).ToString();
                textBox11.Text = jine; // 将金额写到文本控件中

                // 更新全局余额
                DBAccess.Balance = DBAccess.Balance + double.Parse(jine);

                SqlCommand = "insert into 水电费表 values('" + danhao + "','" + roomnum + "','" 
                    + predianbiao + "','" + dianbiao + "','" + preshuibiao + "','" + shuibiao + "','" + jine + "')";
                dbAccess.GetSQLCommand(SqlCommand); //插入水电费纪录
                ShowData();  // 将水电费信息全部显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("此订单已存在！");
            }

        }

        // 加载数据按钮
        private void button4_Click(object sender, EventArgs e)
        {
            ShowData();  // 将水电费信息全部显示到界面上;
        }

        // 修改 水电费纪录
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string danhao, roomnum, predianbiao, dianbiao, preshuibiao, shuibiao, jine, sqltext;
                danhao = textBox12.Text.ToString();
                roomnum = textBox13.Text.ToString();
                predianbiao = textBox10.Text;
                dianbiao = textBox9.Text;
                preshuibiao = textBox8.Text;
                shuibiao = textBox7.Text;
                jine = ((double.Parse(dianbiao) - double.Parse(predianbiao)) * dianprice + (double.Parse(shuibiao) - double.Parse(preshuibiao)) * shuiprice).ToString();

                textBox15.Text = jine;
                // 更新全局余额：减去更新前的数据，加上修改后的数据
                DBAccess.Balance = DBAccess.Balance - PreBalance+ double.Parse(jine);

                SqlCommand = "update 水电费表 set 房屋编号='" + roomnum + "',上次电表数='" 
                    + predianbiao + "',本次电表数='" + dianbiao + "',上次水表数='" 
                    + preshuibiao + "',本次水表数='" + shuibiao + "',金额='" + jine 
                    + "' where danhao='" + danhao + "'";
                dbAccess.GetSQLCommand(SqlCommand); //插入水电费纪录
                ShowData();  // 将水电费信息全部显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("水电费表修改失败！");
            }

        }

        // 删除水电费纪录
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string danhao, sqltext;
                danhao = textBox14.Text.ToString();
                SqlCommand = "delete from 水电费表 where 受理单号='" + danhao + "'";
                dbAccess.GetSQLCommand(SqlCommand);
                ShowData();// 将水电费信息全部显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("删除失败！");
            }

        }
        // 将水电费信息全部显示到界面上
        private void ShowData()
        {
            SqlCommand = "select * from 水电费表 ";  //查询所有结果
                                                  // 将查询结果放到 是视图表中
            dataset = dbAccess.GetDataset(SqlCommand, "水电费表");
            billsdataGridView.DataSource = dataset.Tables[0];
        }

        // 点击单元格，将本行信息放到 修改页面的控件中
        private void billsdataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int row = 0; //行号
            if (billsdataGridView.RowCount > 1)
            {
                // 填充文本框内容
                row = billsdataGridView.CurrentCell.RowIndex;// 获得当前所点击的行数

                textBox12.Text = billsdataGridView[0, row].Value.ToString();
                textBox13.Text = billsdataGridView[1, row].Value.ToString();
                textBox10.Text = billsdataGridView[2, row].Value.ToString();
                textBox9.Text = billsdataGridView[3, row].Value.ToString();
                textBox8.Text = billsdataGridView[4, row].Value.ToString();
                textBox7.Text = billsdataGridView[5, row].Value.ToString();
                textBox15.Text = billsdataGridView[6, row].Value.ToString();

                // 纪录修改前的余额纪录，方便修改时计算
                PreBalance = double.Parse(billsdataGridView[6, row].Value.ToString());
                textBox14.Text = billsdataGridView[0, row].Value.ToString(); // 给删除框那边的单号赋值
            }
        }

        // 查询水电费
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string chaxunfangshi = "danhao";// 查询条件
                if (comboBox1.SelectedItem.ToString().Equals("单号"))
                    chaxunfangshi = "受理单号";
                else if (comboBox1.SelectedItem.ToString().Equals("房屋编号"))
                    chaxunfangshi = "房屋编号";
                if (textBox1.Text.Trim() == "")
                {
                    SqlCommand = "select * from 水电费表 ";  //查询所有结果
                }
                else
                {
                    SqlCommand = "select * from 水电费表 where " + chaxunfangshi 
                        + " like '%" + textBox1.Text + "%'"; // 按条件查询
                }
                // 将查询结果放到 是视图表中
                dataset = dbAccess.GetDataset(SqlCommand, "房屋信息表");
                billsdataGridView.DataSource = dataset.Tables[0];
            }
            catch (Exception)
            {
                MessageBox.Show("查询失败！");
            }

        }
    }
}
