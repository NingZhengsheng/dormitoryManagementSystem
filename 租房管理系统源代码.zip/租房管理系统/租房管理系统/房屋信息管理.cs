﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace 租房管理系统
{
    public partial class 房屋信息管理 : Form
    {
        
        public 房屋信息管理()
        {
            InitializeComponent();
        }

        DBAccess dbAccess = DBAccess.GetInstance();
        DataSet dataset;
        string SqlCommand;

        public bool IsNum(String strNumber) 
        { 
            Regex objNotNumberPattern = new Regex("[^0-9.-]");
            Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*"); 
            Regex objTwoMinusPattern = new Regex("[0-9]*[-][0-9]*[-][0-9]*"); 
            String strValidRealPattern = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$"; 
            String strValidIntegerPattern = "^([-]|[0-9])[0-9]*$";
            Regex objNumberPattern = new Regex("(" + strValidRealPattern + ")|(" + strValidIntegerPattern + ")"); 
            return !objNotNumberPattern.IsMatch(strNumber) && !objTwoDotPattern.IsMatch(strNumber) && !objTwoMinusPattern.IsMatch(strNumber) && objNumberPattern.IsMatch(strNumber); 
        }
        private void Roominf_Load(object sender, EventArgs e)
        {
            ShowData(); // 将房屋信息全部显示到界面上
        }

        // 查询房屋信息管理，点击查询按钮
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string chaxunfangshi = "房屋编号"; // chaxunfangshi 查询方式
                if (comboBox1.SelectedItem.ToString().Equals("房屋编号"))
                    chaxunfangshi = "房屋编号";
                else if (comboBox1.SelectedItem.ToString().Equals("房屋区域"))
                    chaxunfangshi = "房屋区域";
                else if (comboBox1.SelectedItem.ToString().Equals("房屋名称"))
                    chaxunfangshi = "房屋名称";
                else if (comboBox1.SelectedItem.ToString().Equals("房屋状态"))
                    chaxunfangshi = "房屋状态";

               
                if (textBox1.Text.Trim() == "")
                {
                    SqlCommand = "select * from 房屋信息表 ";  //查询所有结果
                }
                else
                {
                    SqlCommand = "select * from 房屋信息表 where " + chaxunfangshi + " like '%" 
                        + textBox1.Text + "%'"; // 按条件查询
                }
                // 将查询结果放到 是视图表中
                dataset = dbAccess.GetDataset(SqlCommand, "房屋信息表");
                roomdataGridView.DataSource = dataset.Tables[0];
            }
            catch (Exception)
            {
                MessageBox.Show("查询失败！");
            }

        }
        //  添加房屋信息 
        private void buttonadd_Click(object sender, EventArgs e)
        {
            try
            {
                // 读取界面所填内容
                string num, mianji, mingzi, weizhi, leixing, zhuangxiu, sheshi, yongtu, jiage, zhuangtai, beizhu;
                string sqltext;
                num = textBox2.Text;
                weizhi = textBox3.Text;
                mingzi = textBox4.Text;
                leixing = textBox5.Text;
                mianji = textBox6.Text;
                zhuangxiu = comboBox2.SelectedItem.ToString();
                sheshi = textBox7.Text;
                yongtu = comboBox3.SelectedItem.ToString();
                jiage = textBox8.Text;
                zhuangtai = comboBox4.SelectedItem.ToString();
                beizhu = textBox9.Text;

                if ((!IsNum(mianji)) || (!IsNum(jiage))) //判断面积或价格是否为数字
                {
                    MessageBox.Show("面积或价格不是数字");
                }
                else
                {
                    sqltext = "insert into 房屋信息表(房屋编号,房屋位置,房屋名称,房屋类型,房屋面积,装修状况,屋内设施,房屋用途,房屋价格,房屋状态,备注信息)" +
                        "values('" + num + "','" + weizhi + "','" + mingzi + "','" + leixing + "','" + mianji + "','" + zhuangxiu + "','" 
                        + sheshi + "','" + yongtu + "','" + jiage + "','" + zhuangtai + "','" + beizhu + "')";
                    dbAccess.GetSQLCommand(sqltext); //添加房屋信息到数据库中

                    ShowData(); // 将房屋信息全部显示到界面上
                }
            }
            catch (Exception)
            {
                MessageBox.Show("添加失败！"); 
            }
            
        }

        // 将房屋信息全部显示到界面上
        private void ShowData()
        {
            SqlCommand = "select * from 房屋信息表 ";  //查询所有结果
                                                  // 将查询结果放到 是视图表中
            dataset = dbAccess.GetDataset(SqlCommand, "房屋信息表");
            roomdataGridView.DataSource = dataset.Tables[0];
        }

        // 加载数据到显示框中
        private void button2_Click(object sender, EventArgs e)
        {
            ShowData(); // 将房屋信息全部显示到界面上
        }

        // 提交修改 修改房屋基本信息
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string num, mianji, mingzi, weizhi, leixing, zhuangxiu, sheshi, yongtu, jiage, zhuangtai, beizhu;
                string sqltext;
                num = textBox17.Text;
                weizhi = textBox16.Text;
                mingzi = textBox15.Text;
                leixing = textBox14.Text;
                mianji = textBox13.Text;
                zhuangxiu = comboBox7.SelectedItem.ToString();
                sheshi = textBox12.Text;
                yongtu = comboBox6.SelectedItem.ToString();
                jiage = textBox11.Text;
                zhuangtai = comboBox5.SelectedItem.ToString();
                beizhu = textBox10.Text;
                if ((!IsNum(mianji)) || (!IsNum(jiage)))
                {
                    MessageBox.Show("面积或价格不是数字");
                }
                else
                {
                    MessageBox.Show("确定修改吗？");

                    sqltext = "update 房屋信息表 set 房屋位置='" + weizhi + "',房屋名称='" + mingzi + "',房屋类型='" 
                        + leixing + "',房屋面积='" + mianji + "',装修状况='" + zhuangxiu + "',屋内设施='" 
                        + sheshi + "',房屋用途='" + yongtu + "',房屋价格='" + jiage + "',房屋状态='" 
                        + zhuangtai + "',备注信息='" + beizhu + "' where 房屋编号='" + num + "'";
                    dbAccess.GetSQLCommand(sqltext); // 修改房屋信息
                    ShowData(); // 将修改后的信息显示到界面上
                }
            }
            catch (Exception)
            {
                MessageBox.Show("修改失败！");
            }

        }

        // 删除房屋信息按钮响应
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string num, sqltext;
                num = textBox18.Text;
                sqltext = "delete from 房屋信息表 where 房屋编号='" + num + "'";
                dbAccess.GetSQLCommand(sqltext); // 删除房屋信息
                ShowData(); // 将删除后的信息显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("删除失败！");
            }

        }

        // 点击单元格，本行数据显示到相应的控件中
        private void roomdataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int row = 0; //行号
            if (roomdataGridView.RowCount > 1)
            {
                // 填充文本框内容
                row = roomdataGridView.CurrentCell.RowIndex;// 获得当前所点击的行数

                textBox17.Text = roomdataGridView[0, row].Value.ToString();
                textBox16.Text = roomdataGridView[1, row].Value.ToString();
                textBox15.Text = roomdataGridView[2, row].Value.ToString();
                textBox14.Text = roomdataGridView[3, row].Value.ToString();
                textBox13.Text = roomdataGridView[4, row].Value.ToString();
                comboBox7.Text = roomdataGridView[5, row].Value.ToString();
                textBox12.Text = roomdataGridView[6, row].Value.ToString();
                comboBox6.Text = roomdataGridView[7, row].Value.ToString();
                textBox11.Text = roomdataGridView[8, row].Value.ToString();
                comboBox5.Text = roomdataGridView[9, row].Value.ToString();
                textBox10.Text = roomdataGridView[10, row].Value.ToString();

                textBox18.Text = roomdataGridView[0, row].Value.ToString(); // 将房屋编号加到删除的房屋编号控件中去
            }
        }
    }
}
