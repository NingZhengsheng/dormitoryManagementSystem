﻿namespace 租房管理系统
{
    partial class 用户信息管理
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(用户信息管理));
            this.userdataGridView = new System.Windows.Forms.DataGridView();
            this.tabPagedel = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPageedit = new System.Windows.Forms.TabPage();
            this.buttonjiazai = new System.Windows.Forms.Button();
            this.buttonupdate = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPageadd = new System.Windows.Forms.TabPage();
            this.buttonadd = new System.Windows.Forms.Button();
            this.textBoxdianhua = new System.Windows.Forms.TextBox();
            this.textBoxname = new System.Windows.Forms.TextBox();
            this.textBoxsfzid = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxsex = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPageinfo = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            ((System.ComponentModel.ISupportInitialize)(this.userdataGridView)).BeginInit();
            this.tabPagedel.SuspendLayout();
            this.tabPageedit.SuspendLayout();
            this.tabPageadd.SuspendLayout();
            this.tabPageinfo.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // userdataGridView
            // 
            this.userdataGridView.AllowUserToAddRows = false;
            this.userdataGridView.AllowUserToDeleteRows = false;
            this.userdataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.userdataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.userdataGridView.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.userdataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.userdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.userdataGridView.Location = new System.Drawing.Point(16, 202);
            this.userdataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.userdataGridView.MultiSelect = false;
            this.userdataGridView.Name = "userdataGridView";
            this.userdataGridView.ReadOnly = true;
            this.userdataGridView.RowTemplate.Height = 23;
            this.userdataGridView.Size = new System.Drawing.Size(879, 385);
            this.userdataGridView.TabIndex = 0;
            this.userdataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.userdataGridView_CellClick);
            // 
            // tabPagedel
            // 
            this.tabPagedel.Controls.Add(this.button4);
            this.tabPagedel.Controls.Add(this.textBox18);
            this.tabPagedel.Controls.Add(this.label25);
            this.tabPagedel.Location = new System.Drawing.Point(4, 25);
            this.tabPagedel.Margin = new System.Windows.Forms.Padding(4);
            this.tabPagedel.Name = "tabPagedel";
            this.tabPagedel.Size = new System.Drawing.Size(871, 141);
            this.tabPagedel.TabIndex = 3;
            this.tabPagedel.Text = "删除用户信息";
            this.tabPagedel.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(552, 72);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(156, 48);
            this.button4.TabIndex = 26;
            this.button4.Text = "删除";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("宋体", 20F);
            this.textBox18.Location = new System.Drawing.Point(247, 72);
            this.textBox18.Margin = new System.Windows.Forms.Padding(4);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(223, 46);
            this.textBox18.TabIndex = 25;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("宋体", 20F);
            this.label25.Location = new System.Drawing.Point(43, 76);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(185, 34);
            this.label25.TabIndex = 24;
            this.label25.Text = "身份证号：";
            // 
            // tabPageedit
            // 
            this.tabPageedit.Controls.Add(this.buttonjiazai);
            this.tabPageedit.Controls.Add(this.buttonupdate);
            this.tabPageedit.Controls.Add(this.textBox2);
            this.tabPageedit.Controls.Add(this.textBox3);
            this.tabPageedit.Controls.Add(this.textBox4);
            this.tabPageedit.Controls.Add(this.label5);
            this.tabPageedit.Controls.Add(this.comboBox2);
            this.tabPageedit.Controls.Add(this.label6);
            this.tabPageedit.Controls.Add(this.label7);
            this.tabPageedit.Controls.Add(this.label10);
            this.tabPageedit.Location = new System.Drawing.Point(4, 25);
            this.tabPageedit.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageedit.Name = "tabPageedit";
            this.tabPageedit.Size = new System.Drawing.Size(871, 141);
            this.tabPageedit.TabIndex = 2;
            this.tabPageedit.Text = "修改用户信息";
            this.tabPageedit.UseVisualStyleBackColor = true;
            // 
            // buttonjiazai
            // 
            this.buttonjiazai.Location = new System.Drawing.Point(673, 18);
            this.buttonjiazai.Margin = new System.Windows.Forms.Padding(4);
            this.buttonjiazai.Name = "buttonjiazai";
            this.buttonjiazai.Size = new System.Drawing.Size(176, 40);
            this.buttonjiazai.TabIndex = 32;
            this.buttonjiazai.Text = "加载数据";
            this.buttonjiazai.UseVisualStyleBackColor = true;
            this.buttonjiazai.Click += new System.EventHandler(this.buttonjiazai_Click);
            // 
            // buttonupdate
            // 
            this.buttonupdate.Location = new System.Drawing.Point(673, 81);
            this.buttonupdate.Margin = new System.Windows.Forms.Padding(4);
            this.buttonupdate.Name = "buttonupdate";
            this.buttonupdate.Size = new System.Drawing.Size(176, 40);
            this.buttonupdate.TabIndex = 31;
            this.buttonupdate.Text = "提交修改";
            this.buttonupdate.UseVisualStyleBackColor = true;
            this.buttonupdate.Click += new System.EventHandler(this.buttonupdate_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("宋体", 15F);
            this.textBox2.Location = new System.Drawing.Point(289, 84);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(327, 36);
            this.textBox2.TabIndex = 30;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("宋体", 15F);
            this.textBox3.Location = new System.Drawing.Point(523, 18);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(147, 36);
            this.textBox3.TabIndex = 26;
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Font = new System.Drawing.Font("宋体", 15F);
            this.textBox4.Location = new System.Drawing.Point(151, 18);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(263, 36);
            this.textBox4.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 15F);
            this.label5.Location = new System.Drawing.Point(189, 88);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 25);
            this.label5.TabIndex = 29;
            this.label5.Text = "电话：";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.Font = new System.Drawing.Font("宋体", 15F);
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "男",
            "女"});
            this.comboBox2.Location = new System.Drawing.Point(96, 84);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(71, 33);
            this.comboBox2.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 15F);
            this.label6.Location = new System.Drawing.Point(21, 88);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 25);
            this.label6.TabIndex = 27;
            this.label6.Text = "性别：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 15F);
            this.label7.Location = new System.Drawing.Point(423, 21);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 25);
            this.label7.TabIndex = 25;
            this.label7.Text = "姓名：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 15F);
            this.label10.Location = new System.Drawing.Point(17, 21);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(137, 25);
            this.label10.TabIndex = 23;
            this.label10.Text = "身份证号：";
            // 
            // tabPageadd
            // 
            this.tabPageadd.Controls.Add(this.buttonadd);
            this.tabPageadd.Controls.Add(this.textBoxdianhua);
            this.tabPageadd.Controls.Add(this.textBoxname);
            this.tabPageadd.Controls.Add(this.textBoxsfzid);
            this.tabPageadd.Controls.Add(this.label9);
            this.tabPageadd.Controls.Add(this.comboBoxsex);
            this.tabPageadd.Controls.Add(this.label8);
            this.tabPageadd.Controls.Add(this.label4);
            this.tabPageadd.Controls.Add(this.label3);
            this.tabPageadd.Location = new System.Drawing.Point(4, 25);
            this.tabPageadd.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageadd.Name = "tabPageadd";
            this.tabPageadd.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageadd.Size = new System.Drawing.Size(871, 141);
            this.tabPageadd.TabIndex = 1;
            this.tabPageadd.Text = "添加用户信息";
            this.tabPageadd.UseVisualStyleBackColor = true;
            // 
            // buttonadd
            // 
            this.buttonadd.Location = new System.Drawing.Point(660, 78);
            this.buttonadd.Margin = new System.Windows.Forms.Padding(4);
            this.buttonadd.Name = "buttonadd";
            this.buttonadd.Size = new System.Drawing.Size(176, 40);
            this.buttonadd.TabIndex = 22;
            this.buttonadd.Text = "添加";
            this.buttonadd.UseVisualStyleBackColor = true;
            this.buttonadd.Click += new System.EventHandler(this.buttonadd_Click);
            // 
            // textBoxdianhua
            // 
            this.textBoxdianhua.Font = new System.Drawing.Font("宋体", 15F);
            this.textBoxdianhua.Location = new System.Drawing.Point(276, 89);
            this.textBoxdianhua.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxdianhua.Name = "textBoxdianhua";
            this.textBoxdianhua.Size = new System.Drawing.Size(327, 36);
            this.textBoxdianhua.TabIndex = 21;
            // 
            // textBoxname
            // 
            this.textBoxname.Font = new System.Drawing.Font("宋体", 15F);
            this.textBoxname.Location = new System.Drawing.Point(509, 22);
            this.textBoxname.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxname.Name = "textBoxname";
            this.textBoxname.Size = new System.Drawing.Size(147, 36);
            this.textBoxname.TabIndex = 3;
            // 
            // textBoxsfzid
            // 
            this.textBoxsfzid.Font = new System.Drawing.Font("宋体", 15F);
            this.textBoxsfzid.Location = new System.Drawing.Point(137, 22);
            this.textBoxsfzid.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxsfzid.Name = "textBoxsfzid";
            this.textBoxsfzid.Size = new System.Drawing.Size(263, 36);
            this.textBoxsfzid.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 15F);
            this.label9.Location = new System.Drawing.Point(176, 92);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 25);
            this.label9.TabIndex = 12;
            this.label9.Text = "电话：";
            // 
            // comboBoxsex
            // 
            this.comboBoxsex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxsex.Font = new System.Drawing.Font("宋体", 15F);
            this.comboBoxsex.FormattingEnabled = true;
            this.comboBoxsex.Items.AddRange(new object[] {
            "男",
            "女"});
            this.comboBoxsex.Location = new System.Drawing.Point(101, 89);
            this.comboBoxsex.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxsex.Name = "comboBoxsex";
            this.comboBoxsex.Size = new System.Drawing.Size(52, 33);
            this.comboBoxsex.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 15F);
            this.label8.Location = new System.Drawing.Point(8, 92);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 25);
            this.label8.TabIndex = 10;
            this.label8.Text = "性别：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 15F);
            this.label4.Location = new System.Drawing.Point(409, 26);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 25);
            this.label4.TabIndex = 2;
            this.label4.Text = "姓名：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 15F);
            this.label3.Location = new System.Drawing.Point(4, 26);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "身份证号：";
            // 
            // tabPageinfo
            // 
            this.tabPageinfo.Controls.Add(this.label2);
            this.tabPageinfo.Controls.Add(this.button1);
            this.tabPageinfo.Controls.Add(this.label1);
            this.tabPageinfo.Controls.Add(this.textBox1);
            this.tabPageinfo.Controls.Add(this.comboBox1);
            this.tabPageinfo.Location = new System.Drawing.Point(4, 25);
            this.tabPageinfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageinfo.Name = "tabPageinfo";
            this.tabPageinfo.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageinfo.Size = new System.Drawing.Size(871, 141);
            this.tabPageinfo.TabIndex = 0;
            this.tabPageinfo.Text = "查询用户信息";
            this.tabPageinfo.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 20F);
            this.label2.Location = new System.Drawing.Point(195, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(287, 34);
            this.label2.TabIndex = 3;
            this.label2.Text = "查询，查询条件：";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(737, 71);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 44);
            this.button1.TabIndex = 5;
            this.button1.Text = "查询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 20F);
            this.label1.Location = new System.Drawing.Point(11, 75);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "按";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("宋体", 12F);
            this.textBox1.Location = new System.Drawing.Point(507, 76);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(221, 30);
            this.textBox1.TabIndex = 4;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("宋体", 12F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "身份证号",
            "姓名",
            "电话",
            "性别"});
            this.comboBox1.Location = new System.Drawing.Point(71, 76);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(115, 28);
            this.comboBox1.TabIndex = 2;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageinfo);
            this.tabControl1.Controls.Add(this.tabPageadd);
            this.tabControl1.Controls.Add(this.tabPageedit);
            this.tabControl1.Controls.Add(this.tabPagedel);
            this.tabControl1.Location = new System.Drawing.Point(16, 26);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(879, 170);
            this.tabControl1.TabIndex = 9;
            // 
            // 用户信息管理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 602);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.userdataGridView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "用户信息管理";
            this.Text = "用户信息管理";
            this.Load += new System.EventHandler(this.Roominf_Load);
            ((System.ComponentModel.ISupportInitialize)(this.userdataGridView)).EndInit();
            this.tabPagedel.ResumeLayout(false);
            this.tabPagedel.PerformLayout();
            this.tabPageedit.ResumeLayout(false);
            this.tabPageedit.PerformLayout();
            this.tabPageadd.ResumeLayout(false);
            this.tabPageadd.PerformLayout();
            this.tabPageinfo.ResumeLayout(false);
            this.tabPageinfo.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView userdataGridView;
        private System.Windows.Forms.TabPage tabPagedel;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabPage tabPageedit;
        private System.Windows.Forms.TabPage tabPageadd;
        private System.Windows.Forms.Button buttonadd;
        private System.Windows.Forms.TextBox textBoxdianhua;
        private System.Windows.Forms.TextBox textBoxname;
        private System.Windows.Forms.TextBox textBoxsfzid;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBoxsex;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPageinfo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button buttonjiazai;
        private System.Windows.Forms.Button buttonupdate;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
    }
}