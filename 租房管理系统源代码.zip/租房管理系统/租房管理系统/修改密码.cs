﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace 租房管理系统
{
    public partial class 修改密码 : Form
    {
        static string currentusernamestr;
        public 修改密码(string currentusername)
        {
            currentusernamestr = currentusername;
            InitializeComponent();
        }

        private void Currentuserpwdedit_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string oldpwd, newpwd, sqltext, sqltext1;
                DataSet ds = new DataSet();
                oldpwd = textBox1.Text;
                newpwd = textBox2.Text;
                sqltext = "select * from 管理员表 where 账号='" + currentusernamestr + "'"+ "and 密码='" + oldpwd + "'";
                sqltext1 = "update 管理员表 set 密码='" + newpwd + "' where 账号='" + currentusernamestr + "'";
                DBAccess dbaccess = new DBAccess();
                SqlDataReader reader = dbaccess.GetReaderofCommand(sqltext);
                if (!reader.HasRows)
                {
                    MessageBox.Show("原密码错误！");
                }
                else
                {
                    MessageBox.Show("密码正确！");
                    reader.Read();
                    dbaccess.GetSQLCommand(sqltext1);
                    MessageBox.Show("修改成功！");
                    //this.Close();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("修改失败！");
            }

        }
    }
}
