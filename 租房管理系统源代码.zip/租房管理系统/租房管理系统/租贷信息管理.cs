﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace 租房管理系统
{
    public partial class 租贷信息管理 : Form
    {
        public 租贷信息管理()
        {
            InitializeComponent();
        }
        DBAccess dbAccess = DBAccess.GetInstance();
        DataSet dataset;
        string SqlCommand;

        public bool IsNum(String strNumber)
        {
            Regex objNotNumberPattern = new Regex("[^0-9.-]");
            Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*");
            Regex objTwoMinusPattern = new Regex("[0-9]*[-][0-9]*[-][0-9]*");
            String strValidRealPattern = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$";
            String strValidIntegerPattern = "^([-]|[0-9])[0-9]*$";
            Regex objNumberPattern = new Regex("(" + strValidRealPattern + ")|(" + strValidIntegerPattern + ")");
            return !objNotNumberPattern.IsMatch(strNumber) && !objTwoDotPattern.IsMatch(strNumber) && !objTwoMinusPattern.IsMatch(strNumber) && objNumberPattern.IsMatch(strNumber);
        }
        private void Rentinf_Load(object sender, EventArgs e)
        {
            try
            {
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                string sqltext1 = "select 房屋编号 from 房屋信息表 ";
                string sqltext2 = "select 身份证号 from 用户信息表 ";
                DataTable dt = new DataTable();
                dataset = dbAccess.GetDataset(sqltext1, "房屋租贷表");
                dt = dataset.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        comboBox1.Items.Add(dt.Rows[i][0].ToString());
                    }
                }
               
                dataset = dbAccess.GetDataset(sqltext2, "房屋租贷表");
                dt = dataset.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        comboBox2.Items.Add(dt.Rows[i][0].ToString());
                    }
                }
                
                comboBox1.SelectedIndex = 0;
                comboBox2.SelectedIndex = 0;


                ShowData();  // 将所有租贷信息全部显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("数据初始化错误！");
            }

        }

        // 添加租贷信息 
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string roomnum, sfznum, date, monthnum, monthlyrent, sqltext;
                roomnum = comboBox1.SelectedItem.ToString();
                sfznum = comboBox2.SelectedItem.ToString();
                date = dateTimePicker1.Text;
                monthnum = textBox1.Text;
                monthlyrent = textBox2.Text;
                if (!IsNum(monthnum) || !IsNum(monthlyrent))
                {
                    MessageBox.Show("月份数或租金值不为数字，请修正！");
                }
                else
                {
                    SqlCommand = "insert into 房屋租贷表 values('" + roomnum + "','" + sfznum + "','" + date + "','" + monthnum + "','" + monthlyrent+" 元" + "')";
                    dbAccess.GetSQLCommand(SqlCommand); // 插入数据
                    ShowData();  // 将所有租贷信息全部显示到界面上
                }
            }
            catch (Exception)
            {
                MessageBox.Show("数据重复，请检查！");
            }
        }

        // 将所有租贷信息全部显示到界面上
        private void ShowData()
        {
            SqlCommand = "select * from 房屋租贷表 ";  //查询所有结果
                                                  // 将查询结果放到 是视图表中
            dataset = dbAccess.GetDataset(SqlCommand, "房屋租贷表");
            rentdataGridView.DataSource = dataset.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string roomnum, sfznum, sqltext;
                roomnum = comboBox1.SelectedItem.ToString();
                sfznum = comboBox2.SelectedItem.ToString();
                SqlCommand = "delete from 房屋租贷表 where 房屋编号='" + roomnum + "' and 身份证号='" + sfznum + "'";
                dbAccess.GetSQLCommand(SqlCommand); // 删除数据
                ShowData();  // 将所有租贷信息全部显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("要求删除的数据不存在，请检查！");
            }
        }
    }
}
