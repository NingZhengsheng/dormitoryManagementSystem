﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 租房管理系统
{
    public partial class 管理员信息管理 : Form
    {
        public 管理员信息管理()
        {
            InitializeComponent();
        }

        DBAccess dbAccess = DBAccess.GetInstance();
        DataSet dataset;
        string SqlCommand;

        // 管理员信息修改 窗口加载时 显示全部信息
        private void Managerinf_Load(object sender, EventArgs e)
        {
            ShowData(); 
        }

        // 添加管理员信息
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string user, pwd;
                user = textBox1.Text;
                pwd = textBox2.Text;
                string sqltext1 = "insert into 管理员表 values('" + user + "','" + pwd + "')";
                dbAccess.GetSQLCommand(sqltext1);  // 添加管理员信息到数据库
                ShowData(); // 将管理员信息全部显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("添加管理员失败！");
            }
        }

        // 将管理员信息全部显示到界面上
        private void ShowData()
        {
            SqlCommand = "select * from 管理员表 ";  //查询管理员表所有结果                                // 将查询结果放到 是视图表中
            dataset = dbAccess.GetDataset(SqlCommand, "管理员表");
            managerdataGridView.DataSource = dataset.Tables[0];
        }

        // 修改管理员信息
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string user, pwd;
                user = textBox1.Text;
                pwd = textBox2.Text;
                string sqltext1 = "update 管理员表 set 密码='" + pwd + "' where 账号='" + user + "'";
                dbAccess.GetSQLCommand(sqltext1);  // 修改管理员信息到数据库
                ShowData(); // 将管理员信息全部显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("修改管理员信息失败！");
            }
        }


        // 删除管理员信息
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string user;
                user = textBox1.Text;
                string sqltext1 = "delete from 管理员表 where 账号='" + user + "'";
                dbAccess.GetSQLCommand(sqltext1);  // 删除管理员信息到数据库
                ShowData(); // 将管理员信息全部显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("删除管理员信息失败！");
            }
        }
    }
}
