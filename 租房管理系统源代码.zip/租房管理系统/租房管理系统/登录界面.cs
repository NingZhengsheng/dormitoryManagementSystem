﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.ComponentModel;
using System.Drawing;
using System.Data.SqlClient;


namespace 租房管理系统
{
    public partial class 登录界面 : Form
    {
        public 登录界面()
        {
            InitializeComponent();
        }
        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void labelclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //点击登录按钮，开始登录
        private void loginbutton_Click(object sender, EventArgs e)
        {
            try
            {
                string username;
                //string sqltext1;
                username = usertextBox.Text;
                //password = textBoxpwd.Text;

                string sqlstr = "select * from 管理员表 where 账号=" + "'"
                        + usertextBox.Text.Trim() + "'"
                        + " and 密码=" + "'" + textBoxpwd.Text.Trim() + "'";
                DBAccess dbaccess = new DBAccess();
                SqlDataReader reader = dbaccess.GetReaderofCommand(sqlstr);

                if (!reader.HasRows)
                {
                    MessageBox.Show("账号错误");
                }
                else
                {
                    reader.Read();
                    主界面 mainform = new 主界面(username);
                    //this.Close();
                    this.Hide();
                    mainform.Show();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("登录失败！");
            }
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        // 点击取消按钮 退出程序
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
