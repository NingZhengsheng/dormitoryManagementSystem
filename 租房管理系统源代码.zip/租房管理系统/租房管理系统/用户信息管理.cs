﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace 租房管理系统
{
    public partial class 用户信息管理 : Form
    {
        public 用户信息管理()
        {
            InitializeComponent();
        }

        DBAccess dbAccess = DBAccess.GetInstance();
        DataSet dataset;
        string SqlCommand;

        public bool IsNum(String strNumber) 
        { 
            Regex objNotNumberPattern = new Regex("[^0-9.-]");
            Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*"); 
            Regex objTwoMinusPattern = new Regex("[0-9]*[-][0-9]*[-][0-9]*"); 
            String strValidRealPattern = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$"; 
            String strValidIntegerPattern = "^([-]|[0-9])[0-9]*$";
            Regex objNumberPattern = new Regex("(" + strValidRealPattern + ")|(" + strValidIntegerPattern + ")"); 
            return !objNotNumberPattern.IsMatch(strNumber) && !objTwoDotPattern.IsMatch(strNumber) && !objTwoMinusPattern.IsMatch(strNumber) && objNumberPattern.IsMatch(strNumber); 
        }

        // 窗口初始化加载
        private void Roominf_Load(object sender, EventArgs e)
        {
            ShowData(); // 将用户信息信息全部显示到界面上
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string chaxunfangshi = "身份证号";  // 用户信息查询方式
            if (comboBox1.SelectedItem.ToString().Equals("身份证号"))
                chaxunfangshi = "身份证号";
            else if (comboBox1.SelectedItem.ToString().Equals("姓名"))
                chaxunfangshi = "姓名";
            else if (comboBox1.SelectedItem.ToString().Equals("电话"))
                chaxunfangshi = "电话";
            else if(comboBox1.SelectedItem.ToString().Equals("性别"))
                chaxunfangshi = "性别";
            try
            {
                if (textBox1.Text.Trim() == "")
                {
                    SqlCommand = "select * from 用户信息表 ";  //查询所有结果
                }
                else
                {
                    SqlCommand = "select * from 用户信息表 where " + chaxunfangshi + " like '%" + textBox1.Text + "%'"; // 按条件查询
                }

                // 将查询结果放到 是视图表中
                dataset = dbAccess.GetDataset(SqlCommand, "用户信息表");
                userdataGridView.DataSource = dataset.Tables[0];
            }
            catch (Exception)
            {
                MessageBox.Show("查询失败！");
            }
        }

        // 将用户信息信息全部显示到界面上
        private void ShowData()
        {
            SqlCommand = "select * from 用户信息表 ";  //查询所有结果
                                                  // 将查询结果放到 是视图表中
            dataset = dbAccess.GetDataset(SqlCommand, "用户信息表");
            userdataGridView.DataSource = dataset.Tables[0];
        }

        private void buttonadd_Click(object sender, EventArgs e)
        {
            try
            {
                string sfzid, username, xingbie, dianhua;
                sfzid = textBoxsfzid.Text;
                username = textBoxname.Text;
                xingbie = comboBoxsex.SelectedItem.ToString();
                dianhua = textBoxdianhua.Text;
                if ((!IsNum(sfzid)) || (!IsNum(dianhua)))
                {
                    MessageBox.Show("身份证号或电话号码不是数字！");
                }
                else
                {
                    SqlCommand = "insert into 用户信息表(身份证号,姓名,性别,电话)" +
                        "values('" + sfzid + "','" + username + "','" + xingbie + "','" + dianhua + "')";
                    dbAccess.GetSQLCommand(SqlCommand);  // 添加用户信息到数据库
                    ShowData(); // 将用户信息信息全部显示到界面上
                }
            }
            catch (Exception)
            {
                MessageBox.Show("该用户已存在！");
            }
        }

        // 删除用户信息
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string sfzid;
                sfzid = textBox18.Text;
                SqlCommand = "delete from 用户信息表 where 身份证号='" + sfzid + "'";
                dbAccess.GetSQLCommand(SqlCommand);  // 删除用户信息到数据库
                ShowData(); // 将用户信息信息全部显示到界面上
            }
            catch (Exception)
            {
                MessageBox.Show("要删除的用户不存在！");
            }

        }

        // 修改用户信息
        private void buttonupdate_Click(object sender, EventArgs e)
        {
            try
            {
                string sfzid, username, xingbie, dianhua;
                sfzid = textBox4.Text;
                username = textBox3.Text;
                xingbie = comboBox2.SelectedItem.ToString();
                dianhua = textBox2.Text;
                if ((!IsNum(sfzid)) || (!IsNum(dianhua)))
                {
                    MessageBox.Show("面积或价格不是数字");
                }
                else
                {
                    SqlCommand = "update 用户信息表 set 姓名='" + username + "',性别='" + xingbie + "',电话='" 
                        + dianhua + "' where 身份证号='" + sfzid + "'";
                    dbAccess.GetSQLCommand(SqlCommand);  // 修改用户信息到数据库
                    ShowData(); // 将用户信息信息全部显示到界面上
                }
            }
            catch (Exception)
            {
                MessageBox.Show("身份证号输入错误！");
            }

        }

        // 加载全部数据
        private void buttonjiazai_Click(object sender, EventArgs e)
        {
            ShowData(); // 将用户信息信息全部显示到界面上
        }

        // 点击单元格 将数据加载到相应的控件中
        private void userdataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int row = 0; //行号
            if (userdataGridView.RowCount > 0)
            {
                // 填充文本框内容
                row = userdataGridView.CurrentCell.RowIndex;// 获得当前所点击的行数
                textBox3.Text = userdataGridView[1, row].Value.ToString();
                comboBox2.Text = userdataGridView[2, row].Value.ToString();
                textBox2.Text = userdataGridView[3, row].Value.ToString();

                textBox18.Text = userdataGridView[0, row].Value.ToString(); // 将身份证号放到删除的身份证号控件中去
                textBox4.Text = userdataGridView[0, row].Value.ToString(); // 将身份证号放到修改的身份证号控件中去
            }
        }
    }
}
